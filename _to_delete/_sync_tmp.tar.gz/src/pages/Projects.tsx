import { Link } from "react-router-dom";

import { PageHeader } from "@/components/site/PageHeader";
import { ProjectTile } from "@/components/site/ProjectCard";
import { projects } from "@/data/site";
import { usePageMeta } from "@/hooks/usePageMeta";

export default function ProjectsPage() {
  usePageMeta(
    "Projects — Selected Work by Couravent",
    "Live sites built for real clients — an experiential marketing agency, a mobile bar company, an infrastructure firm and a project consultancy.",
  );

  return (
    <>
      <PageHeader
        eyebrow="Selected work"
        title="Projects built with intention"
        intro="A selection of live sites, designed and built end to end — click through to see each one in production."
      />

      <section className="mx-auto max-w-6xl px-6 py-20 md:py-28">
        <div className="flex flex-col gap-24">
          {projects.map((project, i) => (
            <article key={project.title} className="grid items-center gap-12 md:grid-cols-2">
              <div className={i % 2 === 1 ? "md:order-2" : ""}>
                <ProjectTile project={project} i={i} />
              </div>
              <div>
                <p className="label-caps">{project.index}</p>
                <h2 className="mt-5 text-3xl text-ink md:text-4xl">{project.title}</h2>
                <p className="mt-3 text-sm font-semibold uppercase tracking-[0.16em] text-accent">
                  {project.role}
                </p>
                <p className="mt-6 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {project.body}
                </p>
                <div className="mt-8 flex flex-wrap gap-2">
                  {project.stack.map((item) => (
                    <span
                      key={item}
                      className="border border-border bg-background px-3 py-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground"
                    >
                      {item}
                    </span>
                  ))}
                </div>
                <a
                  href={project.url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="mt-6 inline-block border-b border-accent pb-1 text-sm text-foreground transition-colors hover:text-accent"
                >
                  Visit live site ↗
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-24 border-t border-border pt-12">
          <Link
            to="/contact"
            className="rounded-full bg-primary px-8 py-4 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-85"
          >
            Discuss your project
          </Link>
        </div>
      </section>
    </>
  );
}
