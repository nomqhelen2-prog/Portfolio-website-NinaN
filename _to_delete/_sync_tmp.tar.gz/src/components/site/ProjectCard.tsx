type Project = {
  index: string;
  title: string;
  role: string;
  body: string;
  stack: string[];
  url: string;
};

const TILE_GRADIENTS = [
  "from-accent/25 via-accent/10 to-transparent",
  "from-primary/20 via-primary/5 to-transparent",
  "from-ink/20 via-ink/5 to-transparent",
  "from-accent/15 via-primary/10 to-transparent",
];

function initials(title: string) {
  return title
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase())
    .join("");
}

function hostname(url: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

export function ProjectTile({ project, i = 0 }: { project: Project; i?: number }) {
  const gradient = TILE_GRADIENTS[i % TILE_GRADIENTS.length];
  return (
    <a
      href={project.url}
      target="_blank"
      rel="noreferrer noopener"
      className={`group flex aspect-4/3 w-full flex-col items-center justify-center gap-3 bg-gradient-to-br ${gradient} shadow-[var(--shadow-soft)] transition-opacity hover:opacity-90`}
      aria-label={`Visit the live ${project.title} site`}
    >
      <span className="font-display text-4xl font-semibold tracking-tight text-ink">
        {initials(project.title)}
      </span>
      <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        {hostname(project.url)}
        <span aria-hidden className="transition-transform group-hover:translate-x-0.5">
          ↗
        </span>
      </span>
    </a>
  );
}
